// Week 5: Learning Team B: Theater Seating Program
// PRG/410: C++ Programming I
// October 24, 2016
// Marcia L. Allen
// Keith
// Michael Aust
// Pharaoh H
// As a culminating activity for Week Five, the Learning Team will be writing the following program
// that can be used by a small theater to sell tickets for performances. The theater's auditorium has
// 10 rows of seats with 9 seats in each row. The program should display a screen that shows which seats are 
// available and which are taken. The screen will show a chart depicting each seat in the theater.
// Seats that are taken are represented by an * symbol, and seats that are available are represented by a # symbol.
// Every time a ticket or group of tickets is purchased, the program should display the total ticket prices and 
// update the seating chart. The program should keep a total of all ticket sales.
// The program should also give the user an option to see a list of how many seats have been sold,
// how many seats are available in each row, and how many seats are available in the entire auditorium.

#include "stdafx.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <istream>
#include <fstream>
using namespace std;

// Intialize variables
const int numberOfRow = 10;
const int numberOfCol = 10;

// Call function that displays the intialized theater seating chart screen
void print(char matrix[][10], int numberOfRow, int numberOfCol);

int _tmain(int argc, _TCHAR* argv[]) {

	// Intialize variables
	char matrix[numberOfRow][numberOfCol], seat[numberOfRow][numberOfCol];
	char option;
	int i, j;
	int row, col;
	int ticketsold = 0;
	bool another = true;

	// Initializes all of the seats to available (*)
	for (i = 0; i < numberOfRow; i++)
		for (j = 0; j < numberOfCol; j++)
			matrix[i][j] = '*';

	while (another)
	{
		print(matrix, numberOfRow, numberOfCol);

		// Display Menu selections
		cout << "\nSales Menu:\n";
		cout << "1)  Purchase Ticket\n";
		cout << "2)  Total Sales and Exit\n\n";
		cout << "Enter Menu Choice: ";
		cin >> option;
		cout << endl << endl;

		switch (option)
		{
		// Loop changes the available seat (*) chosen to unavailable seat (#) or indicates that the seat is not available
		case '1':
		{
			cout << "Enter row: ";
			cin >> row;
			cout << "\nEnter seat: ";
			cin >> col;

			if (matrix[row][col] == '*')
			{
				matrix[row][col] = '#';
				ticketsold++;
			}
			else
			{
				cout << "Sorry, This seat is already taken.\n\n";
			}

			//total revenue
		}

		/*case '2' :
		{
		another=false;
		}

		default :
		cout << "Invalid choice";*/

		}
	}

	system("pause");
}

// Function that displays the theater seating chart screen
void print(char matrix[][10], int numberOfRow, int numberOfCol)
{
	// Intialize variables
	int row, col, i, j;

	cout << "* = Seats Available\n";
	cout << "# = Reserved Seats\n";
	cout << "Seats:  0  1  2  3  4  5  6  7  8  9" << endl;
	
	// Loop to generate the rows
	for (i = 0; i < numberOfRow; i++)
	{
		cout << "Row" << setw(3) << i;
		for (j = 0; numberOfCol > j; j++)
			cout << setw(3) << matrix[i][j];

		cout << endl;
	}

	// return 0;
}

